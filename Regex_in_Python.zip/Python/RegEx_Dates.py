import re
import os.path

txt = input("Enter the (.txt) name: ")

txt = "Files/"+txt+".txt"

if os.path.isfile(txt) :
    text = open(txt, 'r')
    text2 = text.read()

    regex = re.findall(r'[0-1][0-9]\-[0-3][0-9]\-[1-2][0-9][0-9][0-9]|[0-3][0-9]\-[0-1][0-9]\-[1-2][0-9][0-9][0-9]', text2.replace("/", "-"))

    if (regex) :
        print(regex)
    else :
        print("\nNo date found")

    text.close()

else :
    print("\nFile does not exist")

input("\nPress Enter to exit")